package com.fileuploader.fileuploader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileuploaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
